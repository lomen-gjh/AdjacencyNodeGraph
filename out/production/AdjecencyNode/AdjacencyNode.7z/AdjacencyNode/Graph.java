package AdjacencyNode;

import java.awt.*;
import java.util.Map;
import java.util.Vector;

public class Graph {

    public Vector<Node> nodes;

    public Graph(){
        nodes=new Vector<>(0);
    }
    public void addNode(Node node){
        nodes.add(node);
    }
    public void removeNode(Node node){
        //First, remove all neighbors
        //To do this, iterate all neighbors and remove "node" from neighbor hashmap
        for (Map.Entry<Integer, Edge> set: node.neighbors.entrySet()){
            set.getValue().neighbor.removeNeighbor(node);
        }
        nodes.remove(node);
    }
    //DFS
    public void drawGraph(Graphics g){
        Vector<Integer> visited=new Vector<>();
        for (Node node: nodes){
            if (!visited.contains(node.id)){
                //node.neighbors.forEach(); // learn how to use built in foreach
                dfs(node, visited, g);

            }
        }
    }
    public void dfs(Node node, Vector<Integer> visited, Graphics g){
        visited.add(node.id);
        for (Map.Entry<Integer, Edge> set: node.neighbors.entrySet()){
            if (!visited.contains(set.getValue().neighbor.id)){
                g.drawLine(node.x, node.y, set.getValue().neighbor.x,set.getValue().neighbor.y);
                dfs(set.getValue().neighbor, visited, g);
            }
        }
        node.drawNode(g);
    }

    public void connect(Node n1, Node n2, int price){
        n1.addNeighbor(n2,price);
    }

}
